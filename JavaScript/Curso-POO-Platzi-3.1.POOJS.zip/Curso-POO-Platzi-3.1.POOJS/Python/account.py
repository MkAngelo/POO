class Account:
    id          = int
    name        = str
    document    = str
    email       = str
    password    = str