class Payment {
    constructor() {
        this.id;
    }
    
}