class Route {
    constructor(){
        this.id;
        this.init;
        this.end;
    }
}